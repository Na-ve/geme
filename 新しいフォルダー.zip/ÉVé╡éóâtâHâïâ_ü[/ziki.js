﻿//自機のクラス設定
//thisでクラス内の定義


function ziki(posX,posY){
//ジャンプの定数
this.NORMAL_JUMP_POWER = 10;
this.DASH_JUMP_POWER = 13;

//X座標の表示
this.posX = posX;
//Y座標の表示
this.posY = posY;

//アニメーションを切り替えるタイミングの設定
this.animCnt = 0;
//アニメーションの開始点
this.animX = 0;
//ジャンプ時のアニメーションの開始点
this.animOffsetX = 0;
//方向切り替え用の変数
this.direction = RIGHT_DIR;

//ダッシュのフラグ
this.isDash = false;

//ジャンプ
this.isJump = false;
this.jumpCnt = 0;
this.jumpPower = 0;

//マップチップ座標
this.rightMapX = 0;
this.leftMapX = 0;
this.upMapY = 0;
this.downMapY = 0;

}

//描画する関数
ziki.prototype.draw = function(ctx,texture){

//X座標とY座標の始点を動かしてアニメーションを動かす
ctx.drawImage(texture, (this.animX * 32) + this.animOffsetX,this.direction * 32,32,32,this.posX,this.posY,32,32);
}

//移動用の関数
ziki.prototype.moveX = function(moveX){

//移動方向を変える
if(moveX > 0){
this.direction = RIGHT_DIR;
}
else{
this.direction = LEFT_DIR;
}
this.posX += moveX;
//ダッシュ時はアニメーションを早くする
var cnt = this.isDash ? 2 : 1;
this.animCnt += cnt;

//アニメーション
if(this.animCnt >= 12){
this.animCnt = 0;
// 一定以上に達したらアニメーション更新する
if(++this.animX > 3){
this.animX = 0;
}

}

}

ziki.prototype.setIsDash = function(isDash){
this.isDash = isDash;
}




//ジャンプのフラグを立てる
ziki.prototype.setJumpSettings = function(isDash){
if(!this.isJump){
this.isJump = true;
this.animOffsetX = 128;
var jumpNum = isDash ? this.DASH_JUMP_POWER : this.JUMP_POWER;
this.jumpPower = jumpNum;
}

}

//ジャンプの動作
//isPush=対象のキーが押されたか
ziki.prototype.jumpAction = function(isPush){
if(this.isJump){
this.posY -= this.jumpPower;
//落下する量の調整
if(this.jumpPower > -MAX_GRAVITY){
//ジャンプキーが押されている間は落下量を減らす
if(isPush && this.jumpPower > 0){
this.jumpPower -= (GRAVITY_POWER - (GRAVITY_POWER / 2));
}
else{
this.jumpPower -= GRAVITY_POWER;
}

}

//地面についた際
if(this.posY >= 384){
this.posY = 384;
this.isJump = false;
this.animOffsetX = 0;
}

}

}

//マップチップ座標の更新

ziki.prototype.updateMapPosition = function(){

//X座標
this.leftMapX = Math.floor(this.posX / MAP_SIZE);
this.rightMapX = Math.floor((this.posX + MAP_SIZE - 1) / MAP_SIZE);

//配列
if(this.leftMapX >= MAX_MAP_X){
this.leftMapX = MAX_MAP_X;
}

if(this.leftMapX < 0){
this.leftMapX = 0;
}

if(this.rightMapX >= MAX_MAP_X){
this.rightMapX = MAX_MAP_X;
}

if(this.rightMapX < 0){
this.rightMapX = 0;
}

//Y座標
this.upMapY = Math.floor(this.posY / MAP_SIZE);
this.downMapY = Math.floor((this.posY + MAP_SIZE - 1) / MAP_SIZE);

//配列
if(this.upMapY >= MAX_MAP_Y){
this.upMapY = MAX_MAP_Y;
}

if(this.upMapY < 0){
this.upMapY = 0;
}

if(this.downMapY >= MAX_MAP_Y){
this.downMapY = MAX_MAP_Y;
}

if(this.downMapY < 0){
this.downMapY = 0;
}

//ログ
console.log("rightMapX = " + this.rightMapX + ", leftMapX = " + this.leftMapX + ",upMapY = " + this.upMapY + ",this.downMapY = "
+ this.downMapY);

console.log("ziki posX = " + this.posX + ",ziki posY = " + this.posY);
}