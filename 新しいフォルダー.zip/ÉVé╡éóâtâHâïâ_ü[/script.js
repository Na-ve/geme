﻿var g_Canvas;
var g_Ctx;
//自機の定義
var ziki;

//自機のテクスチャ
var zikiTex;
//マップのテクスチャ
var gMapTex;


//キー入力の判定をする変数の定義
var gSpacePush = false; //スペース
var gLeftPush = false;	//左
var gRightPush = false;	//右
var gUpPush = false;	//上
var gDownPush = false;	//下


//キーの定義
var SPACE_KEY = 32;
var LEFT_KEY = 37;
var RIGHT_KEY = 39;
var UP_KEY = 38;
var DOWN_KEY = 40;


//80＝破壊可能ブロック　64＝破壊不能ブロック　112＝地面1左　113＝地面1中　114＝地面1右　128＝地面2左　129＝地面2中　130＝地面2右
var gMapChip = [
[  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
[  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
[  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
[  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
[  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
[  0,  0,  0,  0,  0,  0,  0,  0,  0, 80, 80,  0,  0,  0,  0,  0,  0,  0,  0,  0],
[  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
[  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
[  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
[  0,  0,  0,  0,  0, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,  0,  0,  0,  0,  0],
[  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
[  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
[  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
[112,113,113,113,113,113,113,113,113,113,113,113,113,113,113,113,113,113,113,114],
[128,129,129,129,129,129,129,129,129,129,129,129,129,129,129,129,129,129,129,130]
];


onload = function () {

// キャンバスの設定
g_Canvas = document.getElementById('id_canvas'); 

//コンテキストの取得
g_Ctx = g_Canvas.getContext('2d');

//テクスチャの読み込み
loadTexture();

//自機のオブジェクトの作成
ziki = new ziki(0,384);

// キーの登録
window.addEventListener('keydown', keyDown, true);
window.addEventListener('keyup', keyUp, true);

//loopスタート
requestNextAnimationFrame(animate);
};


//テクスチャの読み込み
function loadTexture(){

//自機の読み込み
zikiTex = new Image();
zikiTex.src = "img/ziki.png";

//マップの読み込み
gMapTex = new Image();
gMapTex.src = "img/map.png";
}


function animate(now) {
move();
// 描画
Draw();
requestNextAnimationFrame(animate);
}

//60fpsの処理を実行
window.requestNextAnimationFrame =
(function () {
   var originalWebkitRequestAnimationFrame = undefined,
       wrapper = undefined,
       callback = undefined,
       geckoVersion = 0,
       userAgent = navigator.userAgent,
       index = 0,
       self = this;

   // Workaround for Chrome 10 bug where Chrome
   // does not pass the time to the animation function

   if (window.webkitRequestAnimationFrame) {
      // Define the wrapper

      wrapper = function (time) {
        if (time === undefined) {
           time = +new Date();
        }
        self.callback(time);
      };

      // Make the switch

      originalWebkitRequestAnimationFrame = window.webkitRequestAnimationFrame;

      window.webkitRequestAnimationFrame = function (callback, element) {
         self.callback = callback;

         // Browser calls the wrapper and wrapper calls the callback

         originalWebkitRequestAnimationFrame(wrapper, element);
      }
   }

   // Workaround for Gecko 2.0, which has a bug in
   // mozRequestAnimationFrame() that restricts animations
   // to 30-40 fps.

   if (window.mozRequestAnimationFrame) {
      // Check the Gecko version. Gecko is used by browsers
      // other than Firefox. Gecko 2.0 corresponds to
      // Firefox 4.0.

      index = userAgent.indexOf('rv:');

      if (userAgent.indexOf('Gecko') != -1) {
         geckoVersion = userAgent.substr(index + 3, 3);

         if (geckoVersion === '2.0') {
            // Forces the return statement to fall through
            // to the setTimeout() function.

            window.mozRequestAnimationFrame = undefined;
         }
      }
   }

   return window.requestAnimationFrame   ||
      window.webkitRequestAnimationFrame ||
      window.mozRequestAnimationFrame    ||
      window.oRequestAnimationFrame      ||
      window.msRequestAnimationFrame     ||

      function (callback, element) {
         var start,
             finish;


         window.setTimeout( function () {
            start = +new Date();
            callback(start);
            finish = +new Date();

            self.timeout = 1000 / 60 - (finish - start);

         }, self.timeout);
      };
   }
)
();
//fps処理の終了

//色と範囲の設定
function Draw(){
//色の設定
g_Ctx.fillStyle = "rgb(0,128,128)";
//塗りつぶす
g_Ctx.fillRect(0,0,640,480);
//マップの描画
drawMap(gMapChip);
//自機の描画
ziki.draw(g_Ctx,zikiTex);
}


//マップチップ
function drawMap(map){
//Y軸
for(var y = 0;y < MAX_MAP_Y;++y){
//X軸
for(var x = 0;x < MAX_MAP_X;++x){
var indexX = 32 * ((map[y][x] + 16) % 16);
var indexY = 32 * Math.floor(map[y][x] / 16);
g_Ctx.drawImage(gMapTex,indexX,indexY,32,32,x * 32,y * 32,32,32);
}

}

}


//自機を動かすための関数
function move(){

// 左キーが押されている状態

//座標の更新
ziki.updateMapPosition();

if(gLeftPush){
if(gSpacePush){
ziki.setIsDash(true);
ziki.moveX(-DASH_SPEED);
}
else{
ziki.setIsDash(false);
ziki.moveX(-NORMAL_SPPED);
}

}

// 右キーが押されている状態
if(gRightPush){
if(gSpacePush){
ziki.setIsDash(true);
ziki.moveX(DASH_SPEED);
}
else{
ziki.setIsDash(false);
ziki.moveX(NORMAL_SPPED);
}

}

// ジャンプ動作
if(gUpPush){
// ジャンプ設定をオンにする
ziki.setJumpSettings(gSpacePush);
}
//ジャンプ処理
ziki.jumpAction(gUpPush);
}


//キーを押した時の操作
function keyDown(event){

//どのキーが押されたか
var code = event.keyCode;
switch(code) {

// スペースキー押された時の判断
case SPACE_KEY:

// スクロールさせないため
event.returnValue = false;
event.preventDefault();
gSpacePush = true;
break;
// 左キーが押された時の判断
case LEFT_KEY:
gLeftPush = true;
break;

// 右キーが押された時の判断
case RIGHT_KEY:
gRightPush = true;
break;

// 上キーが押された時の判断
case UP_KEY:
event.returnValue = false;
event.preventDefault();
gUpPush = true;
break;

// 下キーが押された時の判断キー
case DOWN_KEY:
event.returnValue = false;
event.preventDefault();
gDownPush = true;
break;
	
}

}

//キーを離した時のイベント
function keyUp(event) {
code = event.keyCode;
switch(code) {

// スペースキーの判断
case SPACE_KEY:
gSpacePush = false;
break;

// 左キーの判断
case LEFT_KEY:
gLeftPush = false;
break;

//右キーの判断
case RIGHT_KEY:
gRightPush = false;
break;

//上キーの判断
case UP_KEY:
gUpPush = false;
break;

//下キーの判断
case DOWN_KEY:
gDownPush = false;
break;

}

}